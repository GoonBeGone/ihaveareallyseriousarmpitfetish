@ApiStatus.Internal
package com.misterpemodder.shulkerboxtooltip.impl.config.annotation;

import org.jetbrains.annotations.ApiStatus;
