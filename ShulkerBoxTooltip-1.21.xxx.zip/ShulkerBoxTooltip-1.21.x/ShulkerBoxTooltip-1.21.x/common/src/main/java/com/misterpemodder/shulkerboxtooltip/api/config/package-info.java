/**
 * Provides a view over the mod's configuration.
 *
 * @since 3.3.0
 */
@ApiStatus.AvailableSince("3.3.0")
package com.misterpemodder.shulkerboxtooltip.api.config;

import org.jetbrains.annotations.ApiStatus;