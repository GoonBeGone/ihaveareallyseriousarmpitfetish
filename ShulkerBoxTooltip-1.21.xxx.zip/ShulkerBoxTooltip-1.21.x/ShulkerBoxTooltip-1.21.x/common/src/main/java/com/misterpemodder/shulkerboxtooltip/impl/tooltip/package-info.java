@ApiStatus.Internal
package com.misterpemodder.shulkerboxtooltip.impl.tooltip;

import org.jetbrains.annotations.ApiStatus;
