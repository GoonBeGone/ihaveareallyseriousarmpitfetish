@ApiStatus.Internal
package com.misterpemodder.shulkerboxtooltip.impl.util;

import org.jetbrains.annotations.ApiStatus;
