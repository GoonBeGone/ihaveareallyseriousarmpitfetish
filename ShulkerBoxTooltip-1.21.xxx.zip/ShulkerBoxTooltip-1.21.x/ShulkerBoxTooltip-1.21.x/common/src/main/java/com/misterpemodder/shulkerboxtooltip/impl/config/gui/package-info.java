@ApiStatus.Internal @Environment(EnvType.CLIENT) @ParametersAreNonnullByDefault
package com.misterpemodder.shulkerboxtooltip.impl.config.gui;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jetbrains.annotations.ApiStatus;

import javax.annotation.ParametersAreNonnullByDefault;
