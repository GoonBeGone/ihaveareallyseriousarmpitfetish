@ApiStatus.Internal
package com.misterpemodder.shulkerboxtooltip.impl.tree;

import org.jetbrains.annotations.ApiStatus;
