/**
 * Exposes hooks provided by mixins.
 */

@ApiStatus.Internal
package com.misterpemodder.shulkerboxtooltip.impl.hook;

import org.jetbrains.annotations.ApiStatus;
