@ApiStatus.Internal @ParametersAreNonnullByDefault
package com.misterpemodder.shulkerboxtooltip.impl.provider;

import org.jetbrains.annotations.ApiStatus;

import javax.annotation.ParametersAreNonnullByDefault;
