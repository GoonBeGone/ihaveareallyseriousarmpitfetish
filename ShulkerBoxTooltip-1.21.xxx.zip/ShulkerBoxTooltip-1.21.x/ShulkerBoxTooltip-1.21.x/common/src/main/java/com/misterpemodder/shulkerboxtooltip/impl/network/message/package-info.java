@ApiStatus.Internal
package com.misterpemodder.shulkerboxtooltip.impl.network.message;

import org.jetbrains.annotations.ApiStatus;
