@ApiStatus.Internal @ParametersAreNonnullByDefault
package com.misterpemodder.shulkerboxtooltip.impl.color;

import org.jetbrains.annotations.ApiStatus;

import javax.annotation.ParametersAreNonnullByDefault;
