@ApiStatus.Internal
package com.misterpemodder.shulkerboxtooltip.impl;

import org.jetbrains.annotations.ApiStatus;
