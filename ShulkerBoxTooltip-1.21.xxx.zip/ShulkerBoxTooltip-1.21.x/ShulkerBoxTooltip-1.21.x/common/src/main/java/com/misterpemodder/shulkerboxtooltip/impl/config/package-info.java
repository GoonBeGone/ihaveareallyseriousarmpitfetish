@ApiStatus.Internal
package com.misterpemodder.shulkerboxtooltip.impl.config;

import org.jetbrains.annotations.ApiStatus;
