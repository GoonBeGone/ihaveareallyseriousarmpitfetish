/**
 * ShulkerBoxTooltip preview colors customization API.
 *
 * @since 3.2.0
 */
@ParametersAreNonnullByDefault
package com.misterpemodder.shulkerboxtooltip.api.color;

import javax.annotation.ParametersAreNonnullByDefault;
